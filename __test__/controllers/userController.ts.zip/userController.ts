import { Request, Response } from 'express';
import { expect } from 'chai';
import sinon from 'sinon';
import userController from '../../src/controllers/userController';
import userService from '../../src/services/userService';

describe('User Controller', () => {
    afterEach(()=>{
        sinon.restore();
    })

    describe("getUsers", ()=> {
        it("It should return all users", async () => {
            const mockUserData = [
                {
                    "id": 1,
                    "name": "Alex",
                    "email": "alex@gmail.com"
                },
                {
                    "id": 2,
                    "name": "John",
                    "email": "john@gmail.com"
                }
            ];
            sinon.stub(userService, "getUsers").resolves(mockUserData);

            // Mock req and res objects
            const req = { query: {} } as unknown as Request;
            const res = {
                status: sinon.stub().returnsThis(), // Mock status method to return the res object itself
                json: sinon.spy() // Mock json method
            } as unknown as Response;

            // Call the function
            await userController.getUsers(req, res);

            // Assert the response
            expect(res.status.call(200)).to.be.true;
            expect(res.json.call(mockUserData)).to.be.true;
        })
    })
})