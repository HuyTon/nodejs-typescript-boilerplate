"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
const userService_1 = __importDefault(require("../../src/services/userService"));
describe('User services', () => {
    it("should create a new user", async () => {
        const newUser = userService_1.default.createUser("Alex", "alex@gmail.com");
        (0, chai_1.expect)(newUser).to.deep.equal({
            id: 1,
            name: 'Alex',
            email: 'alex@gmail.com'
        });
    });
});
//# sourceMappingURL=userService.test.js.map