import { expect} from 'chai';
import userService from "../../src/services/userService";

describe('User services', () => {
    it("Get users - should return null if invalid input parameter", async () => {
        const users = await userService.getUsers(10, 10, "id", "asc");

        expect(users).to.be.null;
    }); 
    it("Get users - should return list of users", async () => {
        const users = await userService.getUsers(1, 10, "id", "asc");

        expect(users?.[0]).to.deep.equal({
            id: 1,
            name: "Alex",
            email: "alex@gmail.com"
        });
    });    
    it("Create user - should create a new user", async () => {
        const newUser = await userService.createUser("Alex", "alex@gmail.com");

        expect(newUser).to.deep.equal({
            id: newUser.id,
            name: 'Alex',
            email: 'alex@gmail.com'
        });
    });
});